# AESEncryptionDecryption

In this repository I have shown encryption and decryption of strings in Android Using Kotlin with easiest way. 
You can easily use this way to encrypt and decrypt data in your projects. 



https://github.com/Japnoor2104/AESEncryptionDecryption/assets/109523523/e5966ae2-29df-4fed-becc-9c3b8b148853




I have shown in the below mentioned youtube video that how one can easily make a custom lottie view rather than using readymade lottie. 
->https://youtu.be/oEJqXtsRCQ0

My Instagram account-> https://www.instagram.com/japnoor.here/

Hope it helps you.
